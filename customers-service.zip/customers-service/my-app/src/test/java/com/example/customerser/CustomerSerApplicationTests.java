package com.example.customerser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerSerApplicationTests {

	@Test
	void contextLoads() {
	}

}
